# Expense-Tracker

This is a Complex Expense Budget Tracker Full Stack Application using React, Node.js, speechly the app is called Expense tracker. It helps the users to keep track of the income expenses and its has a voice feature through which you can input the budget with basic command.
![expense-tracker](https://user-images.githubusercontent.com/81036521/156763020-8dadc375-dad3-48a2-bbb0-7aa8c588a33b.JPG)

### `#run npm i && npm start and put speechly.js file code to speechly dashboard and change the key in the application code `
